package game;

import java.util.*;

public class Player extends User { //player child of user.
	 private String passwordHash;


    public Player(String loginName, String password, int chips) {
        super(loginName, chips, password, false, new ArrayList<Card>());
        this.passwordHash = Utility.getHash(password);
    }
    
    
    

    public String getPasswordHash() {
        return passwordHash;
    }
    
    public void display() {
    	super.display();
    	System.out.println(this.getChips());
    }

}

