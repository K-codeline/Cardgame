package game;
public class Card {
    private Suit suit;
    private String name;
    private int value;
    private int rank;
	private int num;

    public enum Suit {
        SPADES,
        HEARTS,
        CLUBS,
        DIAMONDS;
    
    public int getRank() {
              switch(this) {
                  case SPADES:
                      return 4;
                  case HEARTS:
                      return 3;
                  case CLUBS:
                      return 2;
                  case DIAMONDS:
                      return 1;
                  default:
                      return 0;
              }
          }
    }

    public Card(Suit suit, String name, int value, int rank) {
        this.suit = suit;
        this.name = name;
        this.value = value;
        this.rank = rank;
    }

    public Suit getSuit() {
        return this.suit;
    }

    public String getName() {
        return this.name;
    }

    public int getValue() {
        return this.value;
    }

    public int getRank() {
    	int suitRank = this.suit.getRank();
    	int lastDigit = num % 10;//use
        if (this.value >= 1 && this.value <= 9) {
            return suitRank * 100 + this.value;
        } else {
            return suitRank * 100 + 10;
        }
    }

    public String toString() {
        return "<" + this.name + " of " + this.suit.toString() + ">";
    }
}
