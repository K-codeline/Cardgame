package game;

import java.io.*;

public class CreatePlayersBin {

	public static void main (String []args) {
		
		Player player1= new Player ("BlackRanger","Password1",100);
		Player player2= new Player ("BlueKnight","Password2",200);
		Player player3= new Player ("IcePeak","Password3",300);
		
		try {
			FileOutputStream file = new FileOutputStream ("Players.bin");
			ObjectOutputStream opStream= new ObjectOutputStream(file);
			
			
			opStream.writeObject(player1);
			opStream.writeObject(player2);
			opStream.writeObject(player3);
			
			opStream.close();
			
		} catch (IOException ex) {
			ex.printStackTrace();
			}
		}
	}
