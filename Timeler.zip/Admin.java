package game;

import java.util.*;

public class Admin extends User { //player child of user.
	 private String passwordHash;


    public Admin(String loginName, String password, int chips) {
        super(loginName, chips, password, false, new ArrayList<Card>());
        this.passwordHash = Utility.getHash(password);
    }
    
    
    

    public String getPasswordHash() {
        return passwordHash;
    }
    
    public void display() {
    	super.display();
    	System.out.println(this.getChips());
    }

}