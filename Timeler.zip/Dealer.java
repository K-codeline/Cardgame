package game;

import java.util.ArrayList;
import java.util.List;

public class Dealer extends User {//dealer child of player, anything declare static in game.Player is declared

    private Deck deck;

    public Dealer() {
        super("Dealer", 0, "", true, new ArrayList<>());
        this.deck = new Deck();
    }

    public void shuffleCards() {
        System.out.println("The game dealer shuffles the deck");
        this.deck.shuffle();
    }

    public void dealCardTo(User player) {
        Card card = this.deck.dealCard();//take one card from the deck
        player.addCard(card);//pass the card to the player
    }

    public void restart(User player) {
        List<Card> removedCards = player.removeAllCards();
        for (Card card : removedCards) {
            this.deck.appendCard(card);
        }
        this.deck.appendCard(this.getCardsInHand()); // Add dealer's cards to deck
    }

    public void dealerHidecard() {
    	System.out.println(this.getLoginName());
        for (int i = 0; i < this.getCardsInHand().size(); i++) {
            if (i == 0 && this.isdealer()) {
                System.out.print("** ");
            } else {
                System.out.print(this.getCardsInHand().get(i) + " ");
            }
        }

        System.out.println();
    }

}
