package game;


import java.util.*;
import java.io.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class AdminModule {
	
	public ArrayList<Player>players;
	private final String PLAYERS_FILENAME="players.bin";
	private final String ADMIN_FILENAME = "admin.txt";

	
	public AdminModule() {
		players= new ArrayList<Player>();
		saveAdminPassword("CSIT121");		
	}
	
	private void displayLine() {
        System.out.println("--------------------------------------------------");
    }
	
	
	private void displayMenu() {
        displayLine();
        System.out.println("Admin Module Menu");
        displayLine();
        System.out.println("1. Create a player");
        System.out.println("2. Delete a player");
        System.out.println("3. View all players");
        System.out.println("4. Issue more chips to a player");
        System.out.println("5. Reset player's password");
        System.out.println("6. Change administrator's password");
        System.out.println("7. Logout");
        displayLine();
    }
	
	
	public void login() {
		System.out.println("Login please");
		System.out.println("admin Password?");
		Scanner scanner = new Scanner(System.in);
		if (!Utility.getHash(scanner.next()).equals(loadAdminPassword())) {
			System.out.println("Faulty password, try again please");
			login();
		}
	}
	
	private String loadAdminPassword() {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(ADMIN_FILENAME));
			String adminPasswordHash = reader.readLine();
			reader.close();
			return adminPasswordHash;
		} catch (IOException ex) {
			System.out.println("Error loading admin file");
		}
		return null;
	}
	
	private void saveAdminPassword(String newAdminPassword) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(ADMIN_FILENAME));
			String hashedPassword = Utility.getHash(newAdminPassword);
			writer.write(hashedPassword);
			writer.close();
			System.out.println("Admin password changed.");
		} catch (IOException ex) {
			System.out.println("Error saving admin file");
		}
	}
	
	//function 
	private void changeAdminPassword() {
	    Scanner scanner = new Scanner(System.in);
	    while (true) {
	        System.out.print("Enter current admin password: ");
	        String currentPassword = scanner.nextLine();
	        String currentPasswordHash = Utility.getHash(currentPassword);
	        if (!currentPasswordHash.equals(loadAdminPassword())) {
	            System.out.println("Invalid password");
	            continue;
	        }
	        System.out.print("Enter new admin password: ");
	        String newPassword = scanner.nextLine();
	        System.out.print("Confirm new admin password: ");
	        String confirmPassword = scanner.nextLine();
	        if (!newPassword.equals(confirmPassword)) {
	            System.out.println("Passwords do not match");
	            continue;
	        }
	        saveAdminPassword(newPassword);
	        System.out.println("Admin password changed successfully");
	        break;
	    }
	}
	
	
	// PLAYERS ONE START HERE
	
	
	
	
	
	private void loadPlayers() {
		try {
			FileInputStream file = new FileInputStream(PLAYERS_FILENAME);
			ObjectInputStream output= new ObjectInputStream(file);
			
			
			boolean endofFile=false;
			while(!endofFile) {
				try {
					Player player =(Player)output.readObject();
					players.add(player);
					
				}catch (EOFException ex) {
					endofFile= true;
				}
			}
			
			
		}catch(ClassNotFoundException ex) {
			System.out.println("ClassNotFoundException");	
		}catch (FileNotFoundException ex) {
			System.out.println("FileNotFoundException");
		}catch (IOException ex) {
			System.out.println("IOException");
	}
		System.out.println("Players Information Loaded");
	
	}
	
	
	//PROBLEM AREA
	
	
	
	public void displayPlayers() {
		System.out.println("==== All Players ====");
		System.out.printf("%-20s %-65s %s%n", "Login Name", "Password (SHA-256)", "Chips");
		for (Player player: players) {
			System.out.printf("%-20s %-65s %d%n", player.getLoginName(), player.getPassword(), player.getChips());			
			System.out.println("----------------------");
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private void updatePlayersChip() {
	    Scanner scanner = new Scanner(System.in);
	    for (Player player : players) {
	        boolean validInput = false;
	        int amount = 0;
	        while (!validInput) {
	            System.out.print("Enter the amount of chips to add for " + player.getLoginName() + ": ");
	            try {
	                amount = Integer.parseInt(scanner.nextLine());
	                if (amount < 0) {
	                    System.out.println("Invalid input: Please enter a non-negative integer value.");
	                } else {
	                    validInput = true;
	                }
	            } catch (NumberFormatException e) {
	                System.out.println("Invalid input: Please enter a valid integer value.");
	            }
	        }
	        player.addChips(amount);
	    }
	}
	
	//Create Player
	private void createNewPlayer() {
	    Scanner scanner = new Scanner(System.in);
	    System.out.print("Enter player name: ");
	    String loginName = scanner.nextLine();
	    
	    System.out.print("Enter password: ");
	    String password = scanner.nextLine();
	    
	    System.out.print("Enter initial chips: ");
	    int chips = scanner.nextInt();
	    
	    boolean nameTaken = false;
	    for (Player p : players) {
	        if (p.getLoginName().equals(loginName)) {
	            nameTaken = true;
	            break;
	        }
	    }
	    
	    if (nameTaken) {
	        System.out.println("Error: Player name " + loginName + " already taken.");
	    } else {
	        Player player = new Player(loginName, password, chips);
	        players.add(player);
	        System.out.println("New Player Added: " + player.getLoginName());
	    }
	    savePlayersTOBin();
	    
	}
	
	private void savePlayersTOBin() {
		try {
			
			FileOutputStream file = new FileOutputStream (PLAYERS_FILENAME);
			ObjectOutputStream opStream= new ObjectOutputStream(file);
			
			for(Player player: players) {
			opStream.writeObject(player);
			}
			opStream.close();
			
		} catch (IOException ex) {
			System.out.println("IOException");		
			}
	}
	
	//Delete Player
	private void deletePlayer() {
	    Scanner scanner = new Scanner(System.in);
	    System.out.print("Enter the username to delete: ");
	    String username = scanner.nextLine();

	    Player playerToRemove = null;
	    
	    for (Player player : players) {
	        if (player.getLoginName().equals(username)) {
	            playerToRemove = player;
	            break;
	        }
	    }
	    
	    if (playerToRemove != null) {
	        players.remove(playerToRemove);
	        System.out.println(username + " deleted.");
	    } else {
	        System.out.println(username + " not found.");
	    }
	}

	

	//PASSWORD RESET 
	public void resetPlayerPassword() {
		Scanner scanner = new Scanner(System.in);
		Player playerToReset = null;
		while (playerToReset == null) {
		    System.out.print("Enter player name: ");
		    String loginName = scanner.nextLine();
		    
		    for (Player player : players) {
		        if (player.getLoginName().equals(loginName)) {
		            playerToReset = player;
		            break;
		        }
		    }
		    
		    if (playerToReset == null) {
		        System.out.println("Player " + loginName + " not found.");
		    }
		}

		System.out.print("Enter new password: ");
		String newPassword = scanner.nextLine();

		playerToReset.resetPassword(newPassword);
		savePlayersTOBin(); // save the updated players to file
		System.out.println("Password reset for player " + playerToReset.getLoginName());
	}
	
	public void logout() {
		System.out.println("Logout Successful.");
		System.exit(0);
		}
	
	
	
	private boolean promptConfirmation() {
	    System.out.print("Are you sure you want to perform this action? (Y/N): ");
	    Scanner scanner = new Scanner(System.in);
	    String confirmation = scanner.nextLine().trim().toLowerCase();
	    return confirmation.equals("y") || confirmation.equals("yes");
	}

	
	
	 private int promptChoice() {
		 Scanner scanner = new Scanner(System.in);
		    int choice = 0;
		    boolean validInput = false;
		    while (!validInput) {
		        System.out.print("Enter your choice: ");
		        try {
		            choice = Integer.parseInt(scanner.nextLine());
		            validInput = true;
		        } catch (NumberFormatException e) {
		            System.out.println("Invalid input. Please enter a number.");
		        }
		    }
		    return choice;
		}
	 
	 
	 
	 public void run() {
		    login();
		    loadPlayers();

		    int choice=0;
		    boolean returnToMenu = false;
		    do {
		        if (!returnToMenu) {
		            displayMenu();
		            choice = promptChoice();
		        } else {
		            choice = 7; // Set the choice to 7 (Logout) to return to the main menu
		            returnToMenu = false;
		        }

		        switch (choice) {
		            case 1:
		                if (promptConfirmation()) {
		                    createNewPlayer();
		                }
		                break;
		            case 2:
		                if (promptConfirmation()) {
		                    deletePlayer();
		                }
		                break;
		            case 3:
		                displayPlayers();
		                break;
		            case 4:
		                if (promptConfirmation()) {
		                    updatePlayersChip();
		                }
		                break;
		            case 5:
		                if (promptConfirmation()) {
		                    resetPlayerPassword();
		                }
		                break;
		            case 6:
		                if (promptConfirmation()) {
		                    changeAdminPassword();
		                }
		                break;
		            case 7:
		                logout();
		                break;
		            case 8: // Additional option to return to the main menu
		                returnToMenu = true;
		                break;
		            default:
		                System.out.println("Invalid choice. Please try again.");
		                // Wait for user input to continue
		                Scanner scanner = new Scanner(System.in);
		                scanner.nextLine();
		        }
		    } while (choice != 7);
		}

	
	//RUN CODE
	
	 public static void main(String[] args) {
	        AdminModule adminModule = new AdminModule();
	        adminModule.run();
	        }
}
