package game;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;


public class GameModule {
	
	public static ArrayList<Player>players;
    public static int BetAmount;
    private Dealer dealer;
    private Player player;// Set this as null
	private final String PLAYERS_FILENAME="players.bin";
	private String username;
	private String password;
    
	public void readPlayerLoginInfo() {
	    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(PLAYERS_FILENAME))) {
	        players = new ArrayList<>(); // Initialize the players ArrayList

	        while (true) {
	            try {
	                Player player = (Player) ois.readObject();
	                players.add(player); // Add the retrieved player to the players ArrayList
	            } catch (EOFException e) {
	                break; // End of file reached
	            }
	        }
	    } catch (FileNotFoundException e) {
	        System.out.println("Error: File not found - " + PLAYERS_FILENAME);
	    } catch (IOException e) {
	        System.out.println("Error: Failed to read from file - " + PLAYERS_FILENAME);
	        e.printStackTrace();
	    } catch (ClassNotFoundException e) {
	        System.out.println("Error: Failed to deserialize object - " + PLAYERS_FILENAME);
	        e.printStackTrace();
	    }
	}

    
	
	
	
    public GameModule() {
        this.dealer = new Dealer();
        this.player = player;//pLAYER,PASSWROD AND CHIPS
        
           }	

    
	
	
	
    //LOGIN
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        AdminModule adminModule = new AdminModule();

	

       
        
        System.out.println("HighSum GAME");//print message
        System.out.println("================================================================================");

        // Hardcoded player name and password



        // Read player login info from file
        GameModule gameModule = new GameModule();
        gameModule.readPlayerLoginInfo();
        System.out.println(gameModule.username);
        Player currentPlayer = null;
        System.out.println(gameModule.password);
        
        String username = gameModule.username;
        String password = gameModule.password;
        
       
        
        
        // Prompt user to enter login info
        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.print("Enter your login name: ");
            String inputUsername = scanner.nextLine();

            System.out.print("Enter your password: ");
            String inputPassword = scanner.nextLine();

            // Search for a matching player
            for (Player player : players) {
                if (inputUsername.equals(player.getLoginName()) && inputPassword.equals(player.getPassword())) {
                    System.out.println("Login successful!");
                    loggedIn = true;
                    currentPlayer = player;
                    break;
                }
            }

            if (!loggedIn) {
                System.out.println("Incorrect login name or password. Please try again.");
            }
            }
        }
     





        
    public void Gameendvalue() {
        player.showCardsInHand();
        player.showTotalCardValue();
        //only player can view his value.

        dealer.showCardsInHand();
        dealer.showTotalCardValue();
    }

    public void Roundcard() {
        dealer.dealCardTo(player);//pop
        dealer.dealCardTo(dealer);
    }

    public void Roundvalue() { //
        
        player.showCardsInHand();
        player.showTotalCardValue();
    
        //only player can view his value.

        dealer.dealerHidecard();
        
        
        
    }

    public boolean ask(int Playerchip) {
        System.out.println("Do you want to call? [C/Q]");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.next();

        //Check input is not integer
        while (!input.equalsIgnoreCase("C") && !input.equalsIgnoreCase("Q")) {
            try {
                // Try to parse input as a number
                Integer.parseInt(input);
                System.out.println("Invalid input. Please enter 'C' or 'Q'.");
                System.out.println("Do you want to call? [C/Q]");
                input = scanner.next();


            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter 'C' or 'Q'.");
                System.out.println("Do you want to call? [C/Q]");
                input = scanner.next();
            }
        }

        // player calls
        if (input.equalsIgnoreCase("C")) {
            System.out.println("Player call, state bet. Input a number in multiples of 10 and between 10 and " + Playerchip + ": ");
            while (true) {
                try {
                    int BetAmount = scanner.nextInt();
                    if (BetAmount < 10 || BetAmount > Playerchip || BetAmount % 10 != 0) {
                        System.out.print("Invalid bet amount. Input a number in multiples of 10 or  your balance only allows you to make a 10 chip bet " + Playerchip + ": ");
                    } else if (BetAmount > (Playerchip - 30)) {
                        while (BetAmount > (Playerchip - 30)) {
                            System.out.println("NOT ALLOWED TO MAKE MAXIMUM BET. MAX BET IS Player total chips minus 30.");
                            System.out.println("Please enter a new bet amount: ");
                            break;
                        }
                    } else {
                        break;
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter an integer.");
                    scanner.nextLine(); // clear the buffer
                }
            }

        } else if (input.equalsIgnoreCase("Q")) {
            System.out.println("Player fold.");
            System.out.println("Player Amount left:" + (Playerchip));

            return true;
        } else {
            System.out.println("Invalid input. Please enter 'C' or 'Q'.");
        }
        return false;
    }

    public boolean dealerCalls(int Playerchip) {
        System.out.println("dealer call, state bet:" + 10);//dealer will always bet 10

        //YES OR NO SCANNER
        System.out.println("Do you want to Follow? [Y/N]");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.next();

        //Check input is not integer
        while (!input.equalsIgnoreCase("Y") && !input.equalsIgnoreCase("N")) {
            try {
                // Try to parse input as a number
                Integer.parseInt(input);
                System.out.println("Invalid input. Please enter 'Y' or 'N'.");
                System.out.println("Do you want to Follow? [Y/N]");
                input = scanner.next();

            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter 'Y' or 'N'.");
                System.out.println("Do you want to Follow? [Y/N]");
                input = scanner.next();
            }
        }

        // player calls
        if (input.equalsIgnoreCase("Y")) {
            System.out.println("Player follow.");
            BetAmount = 10;


        } else if (input.equalsIgnoreCase("N")) {
            System.out.println("Player fold.");
            System.out.println("Player Amount left:" + (Playerchip));

            return true;
        } else {
            System.out.println("Invalid input. Please enter 'Y' or 'N'.");
        }
        return false;
    }

    public void summary(int Playerchip, int AccumulatedBetAmount) {
        System.out.println("Player, You have " + (Playerchip) + " chips");
        System.out.println("dealer will follow to bet the Amount you betted.");
        System.out.println("Bet on table: " + AccumulatedBetAmount);
    }

    //the game will start here
    public void run() {
        int Playerchip = this.player.getChips();
        int AccumulatedBetAmount = 0;
        int playerRank = player.getrecentcardrank();
        int dealerRank = dealer.getrecentcardrank();
        int playerOnesDigit = playerRank % 10;
        int dealerOnesDigit = dealerRank % 10;
        int playerTensDigit = (playerRank / 10) % 10;
        int dealerTensDigit = (dealerRank / 10) % 10;
        int playerHundredsDigit = playerRank / 100;
        int dealerHundredsDigit = dealerRank / 100;

        String input;

        if (Playerchip < 40) {
            System.out.println("Sorry, you don't have enough chips to play the game.");
            return;
        }

        System.out.println("HighSum Game: ");
        System.out.println("Player, You have " + Playerchip + " chips");
        System.out.println("Game starts - dealer shuffles deck.");
        System.out.println("dealer dealing cards - ROUND 1");

        this.dealer.shuffleCards();

        Scanner scanner = new Scanner(System.in);
         

        while (Playerchip >= 40) {


            Roundcard();
            Roundcard();
            Roundvalue();


            if (playerOnesDigit >= dealerOnesDigit && playerTensDigit>=dealerTensDigit && playerHundredsDigit>=dealerHundredsDigit) {
     
                System.out.println("Player call, state bet. Input a number in multiples of 10 and between 10 and " + Playerchip + ": ");
                while (true) {
                    try {
                        BetAmount = scanner.nextInt();
                        if (BetAmount < 10 || BetAmount > Playerchip || BetAmount % 10 != 0) {
                            System.out.print("Invalid bet amount. Input a number in multiples of 10 or  your balance only allows you to make a 10 chip bet " + Playerchip + ": ");
                        } else if (BetAmount > (Playerchip - 30)) {
                            while (BetAmount > (Playerchip - 30)) {
                                System.out.println("NOT ALLOWED TO MAKE MAXIMUM BET. MAX BET IS Player total chips minus 30.");
                                System.out.println("Please enter a new bet amount: ");
                                break;
                            }
                        } else {
                            break;
                        }
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter an integer.");
                        scanner.nextLine(); // clear the buffer
                    }
                }
            } else {
                boolean fold = dealerCalls(Playerchip);
                if (fold) break;
            }


            AccumulatedBetAmount += BetAmount * 2;//+= keeps track of Total AmountBetted
            Playerchip -= BetAmount;//Playerchip will now minus BetAmount and keep file
            summary(Playerchip, AccumulatedBetAmount);
            System.out.println("=================================================================");
            System.out.println("dealer dealing cards - ROUND 2");


            Roundcard();
            Roundvalue();

            if (playerOnesDigit >= dealerOnesDigit && playerTensDigit>=dealerTensDigit && playerHundredsDigit>=dealerHundredsDigit) {

                boolean fold = ask(Playerchip);
                if (fold) break;

            } else {
                boolean fold = dealerCalls(Playerchip);
                if (fold) break;
            }

            AccumulatedBetAmount += BetAmount * 2;//+= keeps track of Total AmountBetted
            Playerchip -= BetAmount;//Playerchip will now minus BetAmount and keep file
            summary(Playerchip, AccumulatedBetAmount);
            System.out.println("=================================================================");
            System.out.println("dealer dealing cards - ROUND 3");
            Roundcard();
            Roundvalue();
            if (playerOnesDigit >= dealerOnesDigit && playerTensDigit>=dealerTensDigit && playerHundredsDigit>=dealerHundredsDigit) {
                boolean fold = ask(Playerchip);
                if (fold) break;

            } else {
                boolean fold = dealerCalls(Playerchip);
                if (fold) break;
            }


            AccumulatedBetAmount += BetAmount * 2;//+= keeps track of Total AmountBetted
            Playerchip -= BetAmount;//Playerchip will now minus BetAmount and keep file
            summary(Playerchip, AccumulatedBetAmount);
            System.out.println("=================================================================");
            System.out.println("dealer dealing cards - ROUND 4");


            Roundcard();
            Roundvalue();

            if (playerOnesDigit >= dealerOnesDigit && playerTensDigit>=dealerTensDigit && playerHundredsDigit>=dealerHundredsDigit) {
                boolean fold = ask(Playerchip);
                if (fold) break;

            } else {
                boolean fold = dealerCalls(Playerchip);
                if (fold) break;
            }


            AccumulatedBetAmount += BetAmount * 2;//+= keeps track of Total AmountBetted
            Playerchip -= BetAmount;//Playerchip will now minus BetAmount and keep file
            summary(Playerchip, AccumulatedBetAmount);


            System.out.println("============Game End - dealer reveal hidden cards================");

            Gameendvalue();

            if (dealer.getTotalCardValue() > player.getTotalCardValue()) {
                System.out.println("dealer wins");
                System.out.println("Player balance:" + (Playerchip));


                player.deductChips((AccumulatedBetAmount / 2));


            } else if (dealer.getTotalCardValue() < player.getTotalCardValue()) {
                System.out.println("Player wins");
                System.out.println("Player balance:" + (Playerchip + (AccumulatedBetAmount)));


                player.addChips((AccumulatedBetAmount / 2));

            } else {
                System.out.println("It's a tie");
                System.out.println("Player balance:" + (Playerchip) + (AccumulatedBetAmount / 2));

            }

            dealer.restart(player);
            dealer.restart(dealer);

            System.out.println("dealer shuffles used cards and place behind the deck.");

            break;
        }


        System.out.println("Do you want to play again? [Y/N]");
        input = scanner.next();

        //Check input is not integer
        while (!input.equalsIgnoreCase("Y") && !input.equalsIgnoreCase("N")) {
            try {
                // Try to parse input as a number
                int num = Integer.parseInt(input);
                System.out.println("Invalid input. Please enter 'Y' or 'N'.");
                System.out.println("Do you want to play again? [Y/N]");
                input = scanner.next();
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter 'Y' or 'N'.");
                System.out.println("Do you want to play again? [Y/N]");
                input = scanner.next();
            }
        }

        if (input.equalsIgnoreCase("Y")) {
            // Restart the game
            run();
        } else {
            // End the game
            System.out.println("Thanks for playing!");
        }
    }
}

