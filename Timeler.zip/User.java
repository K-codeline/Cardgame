package game;

import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

abstract public class User implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String loginName;
    private int chips;
    private String hashpassword; 
    private boolean isdealer;
    private ArrayList<Card> cardsInHand;


    public User(String loginName, int chips, String password, boolean isdealer, ArrayList<Card> cardsInHand) {
        this.loginName = loginName;
        this.chips = chips;
        this.hashpassword = Utility.getHash(password);
        this.isdealer = isdealer;
        this.cardsInHand = cardsInHand;
    }
    
    
  
    public String getLoginName() {
        return loginName;
    }
    
    
    public boolean checkPassword(String password) {
    	return this.hashpassword.equals(Utility.getHash(password));
    }
    
    
    
    public void display() {
    	System.out.println(this.loginName+","+this.hashpassword);
    }
    
    
    public void resetPassword(String newPassword) {
        this.hashpassword = Utility.getHash(newPassword);
    }
    
    
    
    
    
    
    public int getChips() {
        return this.chips;
    }


    public void addChips(int amount) {
        this.chips += amount;//no error check
    }

    public void deductChips(int amount) {
        this.chips -= amount;//no error check
    }

    public void addCard(Card card) {
        this.cardsInHand.add(card);
    }

    public void showCardsInHand() {
        System.out.println(this.getLoginName());

        for (Card card : cardsInHand) {
            System.out.print(card + " ");
        }
    }
    
    public int getrecentcardrank() {
        if (cardsInHand.size() > 0) { // make sure the hand is not empty
            Card lastCard = cardsInHand.get(cardsInHand.size() - 1); // get the last card
            return lastCard.getRank(); // return the rank of the last card
        } else {
            return 1; // return 0 if the hand is empty
        }
    }    

    public int getTotalCardValue() {
        int total = 0;
        for (Card card : cardsInHand) {
            total += card.getValue();
        }
        return total;
    }

    protected List<Card> removeAllCards() {
        List<Card> removedCards = new ArrayList<>(this.getCardsInHand());
        this.getCardsInHand().clear();
        return removedCards;
    }
    
    public void showrecentcardrank()
    {
        System.out.println("RankingValue: " + getrecentcardrank());
    }

    public void showTotalCardValue() {
        System.out.println("Value: " + getTotalCardValue());
    }

    public ArrayList<Card> getCardsInHand() {
        return this.cardsInHand;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public void setChips(int chips) {
        this.chips = chips;
    }

    public String getPassword() {
        return hashpassword;
    }

    public void setPassword(String password) {
        this.hashpassword = password;
    }

    public boolean isdealer() {
        return isdealer;
    }

    public void setIsdealer(boolean isdealer) {
        this.isdealer = isdealer;
    }

    public void setCardsInHand(ArrayList<Card> cardsInHand) {
        this.cardsInHand = cardsInHand;
    }

}
