package game;

import java.util.*;

import game.Card.Suit;

public class Deck {
    private ArrayList<Card> cards;
   
    public Deck() {
        this.cards = new ArrayList<Card>();
        int rank = 1;
        
        
        
        for (Card.Suit suit : Card.Suit.values()) {
            Card card = new Card(suit, "Ace", 1, rank++);
            cards.add(card);
            
            for (int i = 2; i < 10; i++) {
                Card aCard = new Card(suit, i + "", i, rank++);
                cards.add(aCard);
            }

            String[] pictures = {"Jack", "Queen", "King"};
            for (String picture : pictures) {
                Card picCard = new Card(suit, picture, 10, rank++);
                cards.add(picCard);
            }
        }
    }
    
    
    public void shuffle() {
        Random random = new Random();
        for (int i = 0; i < 10000; i++) {
            int indexA = random.nextInt(cards.size());
            int indexB = random.nextInt(cards.size());
            Card cardA = cards.get(indexA);
            Card cardB = cards.get(indexB);
            cards.set(indexA, cardB);
            cards.set(indexB, cardA);
        }
    }

    public void showCards() {
        for (Card card : cards) {
            System.out.println(card);
        }
    }

    public Card dealCard() {
        return this.cards.remove(0);
    }

    public void appendCard(Card card) {
        this.cards.add(card);
    }


    public void appendCard(ArrayList<Card> cards) {
        for (Card card : cards) {
            appendCard(card);
        }
    }
}
